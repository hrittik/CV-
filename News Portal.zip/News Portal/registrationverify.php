<?php
	
	session_start();
?>
<?php
require 'config.php';
$id=$_POST['id'];
$pass=$_POST['pass'];
$statement="insert into login values ('$id','$pass')";

if(mysqli_query($conn,$statement))
{
    header("location:singleview.php");
}
else
    mysqli_error($conn);

mysqli_close($conn);







?>