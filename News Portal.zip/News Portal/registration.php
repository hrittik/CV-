<!doctype html>
<html>
	<head>
		<title>Registration Form</title>
	</head>
	
	<body>
		<br>
		<br>
		<br>
		
		<h2 align=center>Registration</h2>
		<br>
		<form name="Registration" method="post" action="registrationverify.php">
			<table align=center>
				<tr>
					<th align=left>id</th>
					<th>:</th>
					<th><input type="text" name="id"></th>
				</tr>
				
				<tr>
					<th align=left><br>pass</th>
					<th><br>:</th>
					<th><br><input type="text" name="pass"></th>
				</tr>
				
				
				<tr>
					<th align=left><br><input type="submit" name="submit" ></th>
					<th align=right><br><input type="reset" name="reset" ></th>
				</tr>
				
				
			</table>
			
			
			
		</form>
	</body>
</html>