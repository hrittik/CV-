<?php
		session_start();
		
		require 'config.php';
		
			$id=$_POST['UserName'];
			$pass=$_POST['Password'];
			

            $statement="select * from login where id='$id' and password='$pass'";
            $result = mysqli_query($conn, $statement);

            if (mysqli_num_rows($result) > 0)
            {
                while($row = mysqli_fetch_assoc($result))
                {
                   // echo "<div class='panel-group'><div class='panel panel-primary'><div class='jumbotron'><h2>".$row['heading']."</h2> -By Admin at " .$row['datetime']."</div><div class='panel-body'>".$row['summertext'] ."</div></div></div>";
					$_SESSION['id']=$id;
					$_SESSION['pass']=$pass;
					header("location:setdata.php?invalid=true");
				}
				
            }
            else
            {
                echo "Wrong username or Password!";
            }
            mysqli_close($conn);

?>